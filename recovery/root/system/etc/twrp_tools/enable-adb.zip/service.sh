#!/system/bin/sh
# enable_adb - runs at every boot (KernelSU / Magisk / APatch late_start service).
#
# Uses Android's own settings API, so Android itself turns ADB on and keeps it
# on - no property fighting, works across Android versions.
# If this module carries an adb_keys file (the per-PC build), that public key
# is added to /data/misc/adb/adb_keys so that PC is authorized without the
# "Allow USB debugging?" prompt.

MODDIR=${0%/*}
LOG="$MODDIR/last_boot.log"

# Wait for boot to finish and the settings provider to answer.
i=0
until [ "$(getprop sys.boot_completed)" = 1 ]; do
    sleep 2
    i=$((i + 1)); [ $i -ge 150 ] && break   # give up after ~5 min
done
sleep 5

settings put global development_settings_enabled 1
settings put global adb_enabled 1

if [ -s "$MODDIR/adb_keys" ]; then
    K=/data/misc/adb/adb_keys
    mkdir -p /data/misc/adb
    touch "$K"
    added=0
    while IFS= read -r key; do
        [ -n "$key" ] || continue
        grep -qxF "$key" "$K" || { echo "$key" >> "$K"; added=$((added + 1)); }
    done < "$MODDIR/adb_keys"
    chown system:shell "$K"
    chmod 0640 "$K"
    restorecon "$K" 2>/dev/null
    keymsg=" keys_added=$added"
fi

echo "$(date '+%F %T') dev=$(settings get global development_settings_enabled) adb=$(settings get global adb_enabled)${keymsg}" > "$LOG"
