# customize.sh - used when installed from the KernelSU / APatch / Magisk app.
# (Flashing from a custom recovery uses META-INF/.../update-binary instead.)
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
[ -f "$MODPATH/adb_keys" ] && set_perm "$MODPATH/adb_keys" 0 0 0600
ui_print "- USB debugging will be switched on at every boot"
[ -f "$MODPATH/usb_functions" ] && ui_print "- USB also set to: $(cat "$MODPATH/usb_functions") (ADB kept on)"
[ -f "$MODPATH/adb_keys" ] && ui_print "- This zip also pre-authorizes one PC's ADB key"
ui_print "- Remove the module to stop"
